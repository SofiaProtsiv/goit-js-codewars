function fetchBooks() {}

function fetchBookById(bookId) {}
