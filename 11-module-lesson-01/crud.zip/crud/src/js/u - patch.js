function updateBookById(update, bookId) {}
