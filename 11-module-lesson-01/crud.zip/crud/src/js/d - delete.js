function removeBook(bookId) {}
