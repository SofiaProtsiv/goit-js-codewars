// refs
const inputField = document.querySelector('.search-bar');
const locationBtn = document.querySelector('#get_location_btn');
const searchBtn = document.querySelector('#search_btn');
const infoTxt = document.querySelector('.info_text');
const content = document.querySelector('.content');

let api; // helpful variable for different fetch urls
const APP_ID = '522f7ec766b55c89fccbc47a4e7a72c0'; // SECRET API KEY

inputField.addEventListener('keyup', e => {
  // if user pressed enter btn and input value is not empty, fetch data from specific city(you can you helpful function requestApi, that got city name and make fetch request)
});

locationBtn.addEventListener('click', () => {
  if (navigator.geolocation) {
    // if browser support geolocation api
    // https://developer.mozilla.org/en-US/docs/Web/API/Geolocation/getCurrentPosition

    navigator.geolocation.getCurrentPosition(onSuccess, onError);
  } else {
    alert('Your browser not support geolocation api');
  }
});

function requestApi(city) {
  // use helpful API variable for different fetch urls
  // make fetch request, call helpful fetchData()
}
function onSuccess(position) {
  // getting latitude and longitude of the user device from coords obj
  // use helpful API variable for different fetch urls
  // make fetch request, call helpful fetchData()
}

function fetchData() {
  // infoTxt.innerText = 'Getting weather details...';
  // infoTxt variable has to helpful css classes "error" and "pending" you them
  // fetch(api) and get response or catch error
  // if response is ok, return object with weather and c then function calling weatherDetails function with passing api result as an argument
  // if smth went wrong and response is not ok say that infoTxt.innerText = 'isn't a valid city name'
}

function weatherDetails(data) {
  //getting required properties value from the whole weather information, which we cat from fetch function
  //passing a particular weather info to a particular HTML element what passed below
}
