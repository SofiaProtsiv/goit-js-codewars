const searchBtn = document.getElementById('search-btn');
const mealList = document.getElementById('meal');
const mealDetailsContent = document.querySelector('.meal-details-content');
const recipeCloseBtn = document.getElementById('recipe-close-btn');
const searchInput = document.getElementById('search-input');

// get meal list that matches with the ingredients
function getMealList() {
  // get input value
  let searchInputTxt;

  // fetch list that matches with the ingredients
  //   if (meals){
  //       render meals items, you HTML below
  //       mealList.classList.remove('notFound');
  //   } else {
  //       "Sorry, we didn't find any meal!";
  //       mealList.classList.add('notFound');
  //   }

  // pass into mealList your created meals markup
}

// get recipe of the meal
function getMealRecipe(e) {
  // get recipe of the selected meal
  // call function mealRecipeModal inside this function to render modal markup
}

// create a modal
function mealRecipeModal(meal) {
  // get the object of the selected meal and put it in the modal markup

  // some code for open modal
  mealDetailsContent.parentElement.classList.add('showRecipe');
}

// event listeners
searchBtn.addEventListener('click', getMealList);
mealList.addEventListener('click', getMealRecipe);
recipeCloseBtn.addEventListener('click', () => {
  mealDetailsContent.parentElement.classList.remove('showRecipe');
});
searchInput.addEventListener('keyup', e => {
  // if user pressed enter btn and input value is not empty
  if (e.key === 'Enter' && searchInput.value !== '') {
    getMealList();
    searchInput.value = '';
  }
});
